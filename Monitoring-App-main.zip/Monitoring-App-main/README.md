# Monitoring-App

pyinstaller Monitoring_App.py --noconsole
